//To change color of div

function color()
{
    document.querySelector(".div1").style.backgroundColor="aquamarine";
}

function reset()
{
    document.querySelector(".div1").style.backgroundColor="cornflowerblue";
}

//To change size of div

function size()
{
    document.querySelector(".div1").style.width="800px";
    document.querySelector(".div1").style.height="800px";
    document.querySelector(".myImg").style.width="400px";
    document.querySelector(".myImg").style.height="400px";
    document.querySelector(".myImg").style.marginLeft="200px"
    document.querySelector(".myImg").style.marginTop="200px"
}

//To add a image in div

function adding()
{
    document.querySelector(".myImg").setAttribute("src","pexels-photo-5226130.jpeg");
}

//To remove a image from div

function removing()
{
    document.querySelector(".myImg").setAttribute("src","");
}
